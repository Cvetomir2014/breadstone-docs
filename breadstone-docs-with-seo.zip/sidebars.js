module.exports = {
  sidebar: [
    {
      type: 'category',
      label: 'Breadstone',
      items: ['index', 'token-mining', 'wallet', 'kyc', 'integrations', 'smart-contracts'],
    },
  ],
};

    'architecture',
    'database',
    'kyc-api',