## Smart Contracts

Breadstone използва ERC-20 токен, тестван в Goerli и подготвен за Uniswap листинг.