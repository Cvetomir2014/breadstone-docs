
## KYC API Симулация

### `POST /api/kyc/submit`
Изпраща документи за верификация

```json
{
  "userId": "USER_ID",
  "documentImage": "base64string",
  "selfieImage": "base64string"
}
```

### `GET /api/kyc/status/:userId`
Връща статус на заявката (`pending`, `verified`, `rejected`)
