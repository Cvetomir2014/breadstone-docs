
## ER Диаграма на MongoDB моделите

Breadstone използва MongoDB за съхранение на потребителски данни, сесии за копаене, и заявки за теглене.

```plaintext
+-------------------+
|     User          |
+-------------------+
| _id               |
| username          |
| email             |
| balance           |
| isKycVerified     |
| createdAt         |
+-------------------+

        1
        |
        | owns
        |
        N
+-------------------+
|    MiningSession  |
+-------------------+
| _id               |
| userId (ref)      |
| startTime         |
| endTime           |
| rewardPerHour     |
+-------------------+

        1
        |
        | requests
        |
        N
+-------------------+
| WithdrawalRequest |
+-------------------+
| _id               |
| userId (ref)      |
| amount            |
| walletAddress     |
| status (pending)  |
+-------------------+
```

Моделите се разширяват динамично, като всяка сесия и заявка са обвързани с конкретен потребител.
